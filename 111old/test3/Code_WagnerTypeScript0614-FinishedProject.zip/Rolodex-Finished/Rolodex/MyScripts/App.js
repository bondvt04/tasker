﻿'use strict';

var contactsApp = new angular.module('contactsApp', []);